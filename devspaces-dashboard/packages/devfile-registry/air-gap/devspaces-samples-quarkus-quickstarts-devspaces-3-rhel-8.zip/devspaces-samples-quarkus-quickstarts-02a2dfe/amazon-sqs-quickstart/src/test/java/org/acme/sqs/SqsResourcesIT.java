package org.acme.sqs;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class SqsResourcesIT extends SqsResourcesTest {
    // Runs the same tests as the parent class
}
