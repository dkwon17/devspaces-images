Quarkus guide: https://quarkus.io/guides/funqy-knative-events
