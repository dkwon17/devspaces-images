# Ansible Collection - example.collection

An example collection to show off how to do Ansible collection and role development in Red Hat OpenShift Dev Spaces.
