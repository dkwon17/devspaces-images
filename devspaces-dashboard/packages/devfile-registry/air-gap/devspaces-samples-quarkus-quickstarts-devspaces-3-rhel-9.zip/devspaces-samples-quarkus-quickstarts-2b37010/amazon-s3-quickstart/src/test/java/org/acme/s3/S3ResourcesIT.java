package org.acme.s3;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class S3ResourcesIT extends S3ResourcesTest {
    // Runs the same tests as the parent class
}
