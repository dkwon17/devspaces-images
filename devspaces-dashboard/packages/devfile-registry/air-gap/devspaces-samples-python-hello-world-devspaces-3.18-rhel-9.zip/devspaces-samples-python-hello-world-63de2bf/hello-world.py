# -------------------------------------------------------------
#  Copyright (c) 2022 Red Hat, Inc. All rights reserved.
#  Licensed under the MIT License. See LICENSE in project root.
# -------------------------------------------------------------
# This program prints Hello, world!

str = 'world'
print('Hello, ' + str + '!')
