# Example of the use of Lombok Project
## Lombok Proyect is an open source library for Java that helps reuse repetitive code through annotations
### Find at modelpackage examples of POJOs with and without Lombok, find at Test folder, test methods that ilustrate how lombok behaves.

#### Find Lombok Project official documentation at: https://projectlombok.org/
#### You can see a small tutorial of Lombok Proyect an other Java libraries (in spanish) at: https://codesolt.com/tutoriales/

Feel free to reach me at: carlos.salazar@codesolt.com or find out more about me at: https://carlos-salazar.com/ :)
