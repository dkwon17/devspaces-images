# php Hello, World!

A "Hello, World" PHP script
